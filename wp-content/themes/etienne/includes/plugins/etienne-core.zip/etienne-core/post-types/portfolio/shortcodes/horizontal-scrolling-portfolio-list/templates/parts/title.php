<?php
$item_id = $is_featured ? $featured_project : get_the_ID();
$title_tag = !empty($title_tag) ? $title_tag : 'h4';
?>

<<?php echo esc_attr($title_tag); ?> itemprop="name" class="eltdf-hspli-title entry-title">
<a itemprop="url" class="eltdf-hspli-link" href="<?php echo esc_url( $this_object->getItemLink($params) ); ?>" target="<?php echo esc_attr( $this_object->getItemLinkTarget($params) ); ?>"><?php echo esc_attr(get_the_title($item_id)); ?></a>
</<?php echo esc_attr($title_tag); ?>>
