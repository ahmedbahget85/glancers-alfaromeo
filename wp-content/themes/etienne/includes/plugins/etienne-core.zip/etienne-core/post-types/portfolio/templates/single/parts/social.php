<?php if ( etienne_elated_options()->getOptionValue( 'enable_social_share' ) == 'yes' && etienne_elated_options()->getOptionValue( 'enable_social_share_on_portfolio_item' ) == 'yes' ) : ?>
	<div class="eltdf-ps-info-item eltdf-ps-social-share">
		<?php
		/**
		 * Available params type, icon_type and title
		 *
		 * Return social share html
		 */
        echo etienne_elated_get_social_share_html( array( 'type' => 'dropdown', 'dropdown_behavior' => 'right', 'title' => false ) ); ?>
	</div>
<?php endif; ?>