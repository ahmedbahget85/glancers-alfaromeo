<div class="eltdf-ps-info-item eltdf-ps-content-item">
    <?php the_content(); ?>
</div>