<?php

if ( ! function_exists( 'etienne_core_map_testimonials_meta' ) ) {
	function etienne_core_map_testimonials_meta() {
		$testimonial_meta_box = etienne_elated_create_meta_box(
			array(
				'scope' => array( 'testimonials' ),
				'title' => esc_html__( 'Testimonial', 'etienne-core' ),
				'name'  => 'testimonial_meta'
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_testimonial_title',
				'type'        => 'text',
				'label'       => esc_html__( 'Title', 'etienne-core' ),
				'description' => esc_html__( 'Enter testimonial title', 'etienne-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_testimonial_text',
				'type'        => 'text',
				'label'       => esc_html__( 'Text', 'etienne-core' ),
				'description' => esc_html__( 'Enter testimonial text', 'etienne-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_testimonial_author',
				'type'        => 'text',
				'label'       => esc_html__( 'Author', 'etienne-core' ),
				'description' => esc_html__( 'Enter author name', 'etienne-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_testimonial_author_position',
				'type'        => 'text',
				'label'       => esc_html__( 'Author Position', 'etienne-core' ),
				'description' => esc_html__( 'Enter author job position', 'etienne-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
	}
	
	add_action( 'etienne_elated_action_meta_boxes_map', 'etienne_core_map_testimonials_meta', 95 );
}