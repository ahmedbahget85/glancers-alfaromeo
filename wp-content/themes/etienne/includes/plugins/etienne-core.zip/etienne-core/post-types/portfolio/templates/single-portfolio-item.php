<?php

get_header();

etienne_elated_get_title();

do_action('etienne_elated_action_before_main_content');

etienne_core_get_single_portfolio();

get_footer();