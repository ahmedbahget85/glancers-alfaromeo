<?php

if ( ! function_exists( 'etienne_elated_portfolio_category_additional_fields' ) ) {
	function etienne_elated_portfolio_category_additional_fields() {
		
		$fields = etienne_elated_add_taxonomy_fields(
			array(
				'scope' => 'portfolio-category',
				'name'  => 'portfolio_category_options'
			)
		);
		
		etienne_elated_add_taxonomy_field(
			array(
				'name'   => 'eltdf_portfolio_category_image_meta',
				'type'   => 'image',
				'label'  => esc_html__( 'Category Image', 'etienne-core' ),
				'parent' => $fields
			)
		);
	}
	
	add_action( 'etienne_elated_action_custom_taxonomy_fields', 'etienne_elated_portfolio_category_additional_fields' );
}