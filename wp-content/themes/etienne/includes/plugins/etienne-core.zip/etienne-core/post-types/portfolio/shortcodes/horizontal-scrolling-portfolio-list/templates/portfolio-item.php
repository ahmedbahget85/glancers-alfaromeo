<article class="eltdf-hspl-item <?php echo esc_attr( $this_object->getArticleClasses( $params ) ); ?>">
    <div class="eltdf-hspl-item-inner">
        <div class="eltdf-hspl-item-holder-inner">
            <?php echo etienne_core_get_cpt_shortcode_module_template_part('portfolio', 'horizontal-scrolling-portfolio-list', 'parts/image', '', $params); ?>
            <div class="eltdf-hspl-item-text-holder">
                <div class="eltdf-hspl-text-position">
                    <?php echo etienne_core_get_cpt_shortcode_module_template_part('portfolio', 'horizontal-scrolling-portfolio-list', 'parts/title', '', $params); ?>
                    <?php echo etienne_core_get_cpt_shortcode_module_template_part('portfolio', 'horizontal-scrolling-portfolio-list', 'parts/category', '', $params); ?>
                </div>
            </div>
            <a itemprop="url" class="eltdf-hspli-link" href="<?php echo esc_url( $this_object->getItemLink($params) ); ?>" target="<?php echo esc_attr( $this_object->getItemLinkTarget($params) ); ?>"></a>
        </div>
    </div>
</article>