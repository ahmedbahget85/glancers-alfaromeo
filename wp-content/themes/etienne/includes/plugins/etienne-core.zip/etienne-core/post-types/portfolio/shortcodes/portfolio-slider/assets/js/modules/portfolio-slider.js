(function($) {
    'use strict';

    var portfolioSlider = {};
    eltdf.modules.portfolioSlider = portfolioSlider;

    portfolioSlider.eltdfOnDocumentReady = eltdfOnDocumentReady;
    portfolioSlider.eltdfOnWindowLoad = eltdfOnWindowLoad;
    portfolioSlider.eltdfOnWindowResize = eltdfOnWindowResize;
    portfolioSlider.eltdfOnWindowScroll = eltdfOnWindowScroll;

    $(document).ready(eltdfOnDocumentReady);
    $(window).load(eltdfOnWindowLoad);
    $(window).resize(eltdfOnWindowResize);
    $(window).scroll(eltdfOnWindowScroll);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function eltdfOnDocumentReady() {
        eltdfScrollSlider();
    }

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function eltdfOnWindowLoad() {
        eltdfInitPortfolioSliderHeight();
    }

    /*
     All functions to be called on $(window).resize() should be in this function
     */
    function eltdfOnWindowResize() {
    
    }

    /*
     All functions to be called on $(window).scroll() should be in this function
     */
    function eltdfOnWindowScroll() {
    }

    function eltdfInitPortfolioSliderHeight(){

            var sliders = $('.eltdf-portfolio-slider-holder.eltdf-ps-fullscreen');

            if (sliders.length) {
                sliders.each(function(){
                    var slider = $(this);
                    var fromTop = 0;
                    var dotsHeight = slider.find('.owl-dots:not(.disabled)').outerHeight(true);
                    var subtractHeight=0;
                    var navArrowPrev = slider.find('.owl-nav .owl-prev');
                    var navArrowNext = slider.find('.owl-nav .owl-next');

                    $('.subtract-from-height').each(function() {
                        subtractHeight += $(this).outerHeight(true);
                    });

                    var fromBottom = dotsHeight + subtractHeight;
                    var finalHeight;


                        var calcHeight = function () {
                            if(slider.hasClass('eltdf-ps-minus-header')) {
                                if( eltdf.windowWidth > 1024 ) {
                                    fromTop = $('.eltdf-page-header').outerHeight();
                                } else {
                                    fromTop = $('.eltdf-mobile-header').outerHeight();
                                }
                            }

                            if(eltdf.body.hasClass('admin-bar')) {
                                fromTop =  fromTop + $('#wpadminbar').outerHeight();
                            }
                            finalHeight = eltdf.windowHeight - fromTop - fromBottom;
                            
                            slider.find('.owl-item').each(function(){
                                var thisItem = $(this);
	  
                                thisItem.css({'height': finalHeight});
                            });
	                        
                            slider.find('.owl-nav').css({'height': slider.find('.owl-item').find('.eltdf-pl-item').height()});

                        };

                    if(eltdf.windowHeight >= 640) {
                        calcHeight();
                    }

                    $(window).on('resize', function() {
                        if(eltdf.windowHeight >= 640) {
                            calcHeight();
                        }
                    });

                    var is_colliding = function ($div1, $div2) {
                        var x1 = $div1.offset().left;
                        var y1 = $div1.offset().top;
                        var h1 = $div1.outerHeight(true);
                        var w1 = $div1.outerWidth(true);
                        var b1 = y1 + h1;
                        var r1 = x1 + w1;
                        var x2 = $div2.offset().left;
                        var y2 = $div2.offset().top;
                        var h2 = $div2.outerHeight(true);
                        var w2 = $div2.outerWidth(true);
                        var b2 = y2 + h2;
                        var r2 = x2 + w2;

                        if (b1 < y2 || y1 > b2 || r1 < x2 || x1 > r2) return false;
                        return true;
                    }
                    
	                var showNav = function () {
		
		                slider.find('.owl-item').each(function(){
			                var thisItem = $(this);
			               			       
                            $(this).on('mousemove', function(e){

                                if ( is_colliding(thisItem, navArrowPrev) ) {
                                    console.log('colliding prev');
                                    thisItem.css({'pointer-events': 'none'});
	                                thisItem.find('.eltdf-pli-text-holder').css({'opacity': '0'});
                                }
                                
                                else{
	                                $(this).mouseenter( function(e){
		                                thisItem.find('.eltdf-pli-text-holder').css({'opacity': '1'});
                                    })
	                                $(this).mouseleave( function(e){
		                                thisItem.find('.eltdf-pli-text-holder').css({'opacity': '0'});
	                                })
                                }

                                if ( is_colliding(thisItem, navArrowNext) ) {
                                    console.log('colliding next');
                                    thisItem.css({'pointer-events': 'none'});
	                                thisItem.find('.eltdf-pli-text-holder').css({'opacity': '0'});
                                }

                                else{
	                                $(this).mouseenter( function(e){
		                                thisItem.find('.eltdf-pli-text-holder').css({'opacity': '1'});
	                                })
	                                $(this).mouseleave( function(e){
		                                thisItem.find('.eltdf-pli-text-holder').css({'opacity': '0'});
	                                })
                                }

                            });
			               });
		
		                if(eltdf.windowWidth >= 1367 ) {
			                slider.find('.owl-item').each(function () {
				                var thisItem = $(this);
				                thisItem.css({'pointer-events': 'auto'});
			                });
		                }
		
		                //slider.find('.owl-nav').css({'height': finalHeight});
		
	                };
	                
	          		if(eltdf.windowWidth >= 1367 ) {
			                slider.on('translated.owl.carousel', function(event) {
                                showNav();
			                });
                            showNav();
		                }
	                
                });
            }
    }

    //Move carousel on scroll (only if has class eltdf-ps-scrollable!)
    function eltdfScrollSlider() {
        var sliders = $('.eltdf-portfolio-slider-holder.eltdf-ps-fullscreen');

        if (sliders.length) {
            sliders.each(function() {
                var slider = $(this);
                var isScrolling = false;

                if (slider.hasClass('eltdf-ps-scrollable')) {
                    slider.on('translate.owl.carousel', function() {
                        isScrolling = true;
                    });

                    slider.on('translated.owl.carousel', function() {
                        isScrolling = false;
                    });

                    var isScrollingFn = function () {
                        var owl = slider.find('.eltdf-owl-slider');

                        owl.on('mousewheel', '.owl-stage', function(e) {
                            if (!isScrolling) {
                                if (e.deltaY > 0) {
                                    owl.trigger('prev.owl');
                                } else {
                                    owl.trigger('next.owl');
                                }
                                e.preventDefault();
                            }
                        });
                    }

                    isScrollingFn();
                }
            });
        }
    }



})(jQuery);