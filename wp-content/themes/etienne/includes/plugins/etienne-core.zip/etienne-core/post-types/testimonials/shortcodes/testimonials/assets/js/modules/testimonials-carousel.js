(function ($) {
    'use strict';

    var testimonialsCarousel = {};
    eltdf.modules.testimonialsCarousel = testimonialsCarousel;

    testimonialsCarousel.eltdfInitTestimonials = eltdfInitTestimonialsCarousel;


    testimonialsCarousel.eltdfOnWindowLoad = eltdfOnWindowLoad;

    $(window).load(eltdfOnWindowLoad);

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function eltdfOnWindowLoad() {
        eltdfInitTestimonialsCarousel();
    }

    /**
     * Init testimonials shortcode elegant type
     */
    function eltdfInitTestimonialsCarousel(){
        var testimonial = $('.eltdf-testimonials-holder.eltdf-testimonials-carousel');

        if(testimonial.length){
            
            testimonial.each(function(){
                var thisTestimonials = $(this),
                    mainTestimonialsSlider = thisTestimonials.find('.eltdf-testimonials-main'),
                    imagePagSlider = thisTestimonials.children('.eltdf-testimonial-image-nav'),
                    loop = true,
                    autoplay = true,
                    sliderSpeed = 5000,
                    sliderSpeedAnimation = 600,
                    mouseDrag = false;

                if (mainTestimonialsSlider.data('enable-loop') === 'no') {
                    loop = false;
                }
                if (mainTestimonialsSlider.data('enable-autoplay') === 'no') {
                    autoplay = false;
                }
                if (typeof mainTestimonialsSlider.data('slider-speed') !== 'undefined' && mainTestimonialsSlider.data('slider-speed') !== false) {
                    sliderSpeed = mainTestimonialsSlider.data('slider-speed');
                }
                if (typeof mainTestimonialsSlider.data('slider-speed-animation') !== 'undefined' && mainTestimonialsSlider.data('slider-speed-animation') !== false) {
                    sliderSpeedAnimation = mainTestimonialsSlider.data('slider-speed-animation');
                }
                if(eltdf.windowWidth < 680){
                    mouseDrag = true;
                }
                
                if (mainTestimonialsSlider.length && imagePagSlider.length) {
                    var text = mainTestimonialsSlider.owlCarousel({
                        items: 1,
                        loop: loop,
                        autoplay: autoplay,
                        autoplayTimeout: sliderSpeed,
                        smartSpeed: sliderSpeedAnimation,
                        autoplayHoverPause: true,
                        dots: false,
                        nav: true,
                        mouseDrag: false,
                        touchDrag: false,
	                    navText: [
		                    '<span class="eltdf-icon-shortcode eltdf-normal   "><i class="eltdf-icon-linea-icon icon-arrows-slim-left eltdf-icon-element" style=""></i></span>',
		                    '<span class="eltdf-icon-shortcode eltdf-normal   "><i class="eltdf-icon-linea-icon icon-arrows-slim-right eltdf-icon-element" style=""></i></span>'
	                    ],
                        onInitialize: function () {
                            mainTestimonialsSlider.css('visibility', 'visible');
                        }
                    });

                    var image = imagePagSlider.owlCarousel({
                        loop: loop,
                        autoplay: autoplay,
                        autoplayTimeout: sliderSpeed,
                        smartSpeed: sliderSpeedAnimation,
                        autoplayHoverPause: true,
                        center: true,
                        dots: false,
                        nav: false,
                        mouseDrag: false,
                        touchDrag: false,
	                    navText: [
		                    '<span class="eltdf-icon-shortcode eltdf-normal   "><i class="eltdf-icon-linea-icon icon-arrows-slim-left eltdf-icon-element" style=""></i></span>',
		                    '<span class="eltdf-icon-shortcode eltdf-normal   "><i class="eltdf-icon-linea-icon icon-arrows-slim-right eltdf-icon-element" style=""></i></span>'
	                    ],
                        responsive: {
                            1025: {
                                items: 3
                            },
                            0: {
                                items: 3
                            }
                        },
                        onInitialize: function () {
                            imagePagSlider.css('visibility', 'visible');
                            thisTestimonials.css('opacity', '1');
                            imagePagSlider.appear(function(){$(this).addClass('eltdf-show')});
                        }
                    });
	
	                mainTestimonialsSlider.find('.owl-prev').on('click touchpress', function (e) {
		                e.preventDefault();
		                imagePagSlider.trigger('prev.owl.carousel');
	                });
                 
	                mainTestimonialsSlider.find('.owl-next').on('click touchpress', function (e) {
		                e.preventDefault();
		                imagePagSlider.trigger('next.owl.carousel');
	                });
                    
                    imagePagSlider.find('.owl-item').on('click touchpress', function (e) {
                        e.preventDefault();
                        var thisItem = $(this),
                            itemIndex = thisItem.index(),
                            numberOfClones = imagePagSlider.find('.owl-item.cloned').length,
                            modifiedItems = itemIndex - numberOfClones / 2 >= 0 ? itemIndex - numberOfClones / 2 : itemIndex;
                        
                        image.trigger('to.owl.carousel', modifiedItems);
                        text.trigger('to.owl.carousel', modifiedItems);
                    });
                }
            });
        }
    }

})(jQuery);