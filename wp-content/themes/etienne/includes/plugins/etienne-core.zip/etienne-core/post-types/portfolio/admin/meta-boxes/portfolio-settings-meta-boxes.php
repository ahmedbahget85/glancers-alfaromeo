<?php

if ( ! function_exists( 'etienne_core_map_portfolio_settings_meta' ) ) {
	function etienne_core_map_portfolio_settings_meta() {
		$meta_box = etienne_elated_create_meta_box( array(
			'scope' => 'portfolio-item',
			'title' => esc_html__( 'Portfolio Settings', 'etienne-core' ),
			'name'  => 'portfolio_settings_meta_box'
		) );
		
		etienne_elated_create_meta_box_field( array(
			'name'        => 'eltdf_portfolio_single_template_meta',
			'type'        => 'select',
			'label'       => esc_html__( 'Portfolio Type', 'etienne-core' ),
			'description' => esc_html__( 'Choose a default type for Single Project pages', 'etienne-core' ),
			'parent'      => $meta_box,
			'options'     => array(
				''                  => esc_html__( 'Default', 'etienne-core' ),
				'huge-images'       => esc_html__( 'Portfolio Full Width Images', 'etienne-core' ),
				'images'            => esc_html__( 'Portfolio Images', 'etienne-core' ),
				'small-images'      => esc_html__( 'Portfolio Small Images', 'etienne-core' ),
				'slider'            => esc_html__( 'Portfolio Slider', 'etienne-core' ),
				'small-slider'      => esc_html__( 'Portfolio Small Slider', 'etienne-core' ),
				'gallery'           => esc_html__( 'Portfolio Gallery', 'etienne-core' ),
				'small-gallery'     => esc_html__( 'Portfolio Small Gallery', 'etienne-core' ),
				'masonry'           => esc_html__( 'Portfolio Masonry', 'etienne-core' ),
				'masonry-bellow'    => esc_html__( 'Portfolio Masonry Images Bellow', 'etienne-core' ),
				'small-masonry'     => esc_html__( 'Portfolio Small Masonry', 'etienne-core' ),
				'custom'            => esc_html__( 'Portfolio Custom', 'etienne-core' ),
				'full-width-custom' => esc_html__( 'Portfolio Full Width Custom', 'etienne-core' )
			)
		) );
		
		/***************** Gallery Layout *****************/
		
		$gallery_type_meta_container = etienne_elated_add_admin_container(
			array(
				'parent'          => $meta_box,
				'name'            => 'eltdf_gallery_type_meta_container',
				'dependency' => array(
					'show' => array(
						'eltdf_portfolio_single_template_meta'  => array(
							'gallery',
							'small-gallery'
						)
					)
				)
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_portfolio_single_gallery_columns_number_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Number of Columns', 'etienne-core' ),
				'default_value' => '',
				'description'   => esc_html__( 'Set number of columns for portfolio gallery type', 'etienne-core' ),
				'parent'        => $gallery_type_meta_container,
				'options'       => etienne_elated_get_number_of_columns_array( true, array( 'one', 'five', 'six' ) )
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_portfolio_single_gallery_space_between_items_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Space Between Items', 'etienne-core' ),
				'description'   => esc_html__( 'Set space size between columns for portfolio gallery type', 'etienne-core' ),
				'default_value' => '',
				'options'       => etienne_elated_get_space_between_items_array( true ),
				'parent'        => $gallery_type_meta_container
			)
		);
		
		/***************** Gallery Layout *****************/
		
		/***************** Masonry Layout *****************/
		
		$masonry_type_meta_container = etienne_elated_add_admin_container(
			array(
				'parent'          => $meta_box,
				'name'            => 'eltdf_masonry_type_meta_container',
				'dependency' => array(
					'show' => array(
						'eltdf_portfolio_single_template_meta'  => array(
							'masonry',
							'small-masonry',
							'masonry-bellow'
						)
					)
				)
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_portfolio_single_masonry_columns_number_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Number of Columns', 'etienne-core' ),
				'default_value' => '',
				'description'   => esc_html__( 'Set number of columns for portfolio masonry type', 'etienne-core' ),
				'parent'        => $masonry_type_meta_container,
				'options'       => etienne_elated_get_number_of_columns_array( true, array( 'one', 'five', 'six' ) )
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_portfolio_single_masonry_space_between_items_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Space Between Items', 'etienne-core' ),
				'description'   => esc_html__( 'Set space size between columns for portfolio masonry type', 'etienne-core' ),
				'default_value' => '',
				'options'       => etienne_elated_get_space_between_items_array( true ),
				'parent'        => $masonry_type_meta_container
			)
		);
		
		/***************** Masonry Layout *****************/
		
		etienne_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_show_title_area_portfolio_single_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Show Title Area', 'etienne-core' ),
				'description'   => esc_html__( 'Enabling this option will show title area on your single portfolio page', 'etienne-core' ),
				'parent'        => $meta_box,
				'options'       => etienne_elated_get_yes_no_select_array()
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'        => 'portfolio_info_top_padding',
				'type'        => 'text',
				'label'       => esc_html__( 'Portfolio Info Top Padding', 'etienne-core' ),
				'description' => esc_html__( 'Set top padding for portfolio info elements holder. This option works only for Portfolio Images, Slider, Gallery and Masonry portfolio types', 'etienne-core' ),
				'parent'      => $meta_box,
				'args'        => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'        => 'portfolio_external_link',
				'type'        => 'text',
				'label'       => esc_html__( 'Portfolio External Link', 'etienne-core' ),
				'description' => esc_html__( 'Enter URL to link from Portfolio List page', 'etienne-core' ),
				'parent'      => $meta_box,
				'args'        => array(
					'col_width' => 3
				)
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_portfolio_featured_image_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Featured Image', 'etienne-core' ),
				'description' => esc_html__( 'Choose an image for Portfolio Lists shortcode where Hover Type option is Switch Featured Images', 'etienne-core' ),
				'parent'      => $meta_box
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_portfolio_masonry_fixed_dimensions_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Dimensions for Masonry - Image Fixed Proportion', 'etienne-core' ),
				'description'   => esc_html__( 'Choose image layout when it appears in Masonry type portfolio lists where image proportion is fixed', 'etienne-core' ),
				'default_value' => '',
				'parent'        => $meta_box,
				'options'       => array(
					''                   => esc_html__( 'Default', 'etienne-core' ),
					'small'              => esc_html__( 'Small', 'etienne-core' ),
					'large-width'        => esc_html__( 'Large Width', 'etienne-core' ),
					'large-height'       => esc_html__( 'Large Height', 'etienne-core' ),
					'large-width-height' => esc_html__( 'Large Width/Height', 'etienne-core' )
				)
			)
		);
		
		etienne_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_portfolio_masonry_original_dimensions_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Dimensions for Masonry - Image Original Proportion', 'etienne-core' ),
				'description'   => esc_html__( 'Choose image layout when it appears in Masonry type portfolio lists or in Horizontal Scrolling Portfolio List where image proportion is original', 'etienne-core' ),
				'default_value' => '',
				'parent'        => $meta_box,
				'options'       => array(
					''            => esc_html__( 'Default', 'etienne-core' ),
					'large-width' => esc_html__( 'Large Width', 'etienne-core' )
				)
			)
		);
		
		$all_pages = array();
		$pages     = get_pages();
		foreach ( $pages as $page ) {
			$all_pages[ $page->ID ] = $page->post_title;
		}
		
		etienne_elated_create_meta_box_field(
			array(
				'name'        => 'portfolio_single_back_to_link',
				'type'        => 'select',
				'label'       => esc_html__( '"Back To" Link', 'etienne-core' ),
				'description' => esc_html__( 'Choose "Back To" page to link from portfolio Single Project page', 'etienne-core' ),
				'parent'      => $meta_box,
				'options'     => $all_pages,
				'args'        => array(
					'select2' => true
				)
			)
		);
	}
	
	add_action( 'etienne_elated_action_meta_boxes_map', 'etienne_core_map_portfolio_settings_meta', 41 );
}