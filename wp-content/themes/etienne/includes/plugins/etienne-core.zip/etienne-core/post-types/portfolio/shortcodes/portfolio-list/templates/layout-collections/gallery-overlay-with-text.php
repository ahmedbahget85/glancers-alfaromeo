<?php echo etienne_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/image', $item_style, $params); ?>

<div class="eltdf-pli-text-holder">
	<a itemprop="url" class="eltdf-pli-link eltdf-block-drag-link" href="<?php echo esc_url( $this_object->getItemLink() ); ?>" target="<?php echo esc_attr( $this_object->getItemLinkTarget() ); ?>"></a>
	<div class="eltdf-pli-text">
		<?php echo etienne_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/title', $item_style, $params); ?>
		
		<?php echo etienne_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/category', $item_style, $params); ?>
		
		<?php echo etienne_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/images-count', $item_style, $params); ?>
		
		<?php echo etienne_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/excerpt', $item_style, $params); ?>
		
		<?php echo etienne_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/share', $item_style, $params); ?>
	</div>
	<div class="eltdf-pli-mark"><a itemprop="url" class="eltdf-pli-link eltdf-block-drag-link" href="<?php echo esc_url( $this_object->getItemLink() ); ?>" target="<?php echo esc_attr( $this_object->getItemLinkTarget() ); ?>"></a><?php esc_html_e( '+', 'etienne-core' ); ?></div>
</div>