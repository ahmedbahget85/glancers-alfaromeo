<?php if(etienne_elated_show_comments()) : ?>
    <?php comments_template('', true); ?>
<?php endif; ?>