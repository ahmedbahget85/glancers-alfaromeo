(function($) {
	'use strict';
	
	var testimonialsImagePagination = {};
	eltdf.modules.testimonialsImagePagination = testimonialsImagePagination;
	
	testimonialsImagePagination.eltdfOnDocumentReady = eltdfOnDocumentReady;
	
	$(document).ready(eltdfOnDocumentReady);
	
	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function eltdfOnDocumentReady() {
		eltdfTestimonialsImagePagination();
	}
	
	/**
	 * Init Owl Carousel
	 */
	function eltdfTestimonialsImagePagination() {
		var sliders = $('#eltdf-testimonial-pagination');
		
		if (sliders.length) {
			sliders.each(function() {
				var slider = $(this),
					slideItemsNumber = slider.children().length,
					contentItems = slider.siblings('.eltdf-testimonials').find('.eltdf-testimonial-content'),
					loop = true,
					autoplay = false,
					autoplayHoverPause = true,
					sliderSpeed = 3500,
					sliderSpeedAnimation = 500,
					margin = 0,
					stagePadding = 0,
					center = false,
					autoWidth = false,
					animateInClass = false, // keyframe css animation
					animateOutClass = false, // keyframe css animation
					navigation = true,
					pagination = false,
					drag = false,
					nav = true,
					sliderDataHolder = slider;
				
				if (sliderDataHolder.data('enable-loop') === 'no') {
					loop = false;
				}
				if (sliderDataHolder.data('enable-center') === 'yes') {
					center = true;
				}
				if (typeof sliderDataHolder.data('slider-speed') !== 'undefined' && sliderDataHolder.data('slider-speed') !== false) {
					sliderSpeed = sliderDataHolder.data('slider-speed');
				}
				if (typeof sliderDataHolder.data('slider-speed-animation') !== 'undefined' && sliderDataHolder.data('slider-speed-animation') !== false) {
					sliderSpeedAnimation = sliderDataHolder.data('slider-speed-animation');
				}
				if (sliderDataHolder.data('enable-auto-width') === 'yes') {
					autoWidth = true;
				}
				if (typeof sliderDataHolder.data('slider-animate-in') !== 'undefined' && sliderDataHolder.data('slider-animate-in') !== false) {
					animateInClass = sliderDataHolder.data('slider-animate-in');
				}
				if (typeof sliderDataHolder.data('slider-animate-out') !== 'undefined' && sliderDataHolder.data('slider-animate-out') !== false) {
					animateOutClass = sliderDataHolder.data('slider-animate-out');
				}
				if (sliderDataHolder.data('enable-navigation') === 'no') {
					navigation = false;
				}
				if (sliderDataHolder.data('enable-pagination') === 'yes') {
					pagination = true;
				}
				if (sliderDataHolder.data('enable-autoplay') === 'yes') {
					autoplay = true;
				}
				
				if (navigation && pagination) {
					slider.addClass('eltdf-slider-has-both-nav');
				}
				
				$('.eltdf-testimonials-image-pagination .eltdf-testimonial-content').eq(1).addClass('active');
				
				if (slideItemsNumber <= 1) {
					loop = false;
					autoplay = false;
					navigation = false;
					pagination = false;
				}
				
				slider.waitForImages(function () {
					$(this).owlCarousel({
						items: 3,
						loop: loop,
						autoplay: autoplay,
						autoplayHoverPause: autoplayHoverPause,
						autoplayTimeout: sliderSpeed,
						smartSpeed: sliderSpeedAnimation,
						margin: margin,
						stagePadding: stagePadding,
						center: center,
						autoWidth: autoWidth,
						animateIn: animateInClass,
						animateOut: animateOutClass,
						dots: pagination,
						// dotsContainer: dotsContainer,
						nav: navigation,
						drag: drag,
						callbacks: true,
						navText: [
							'<span class="eltdf-icon-shortcode eltdf-normal   "><i class="eltdf-icon-linea-icon icon-arrows-slim-left eltdf-icon-element" style=""></i></span>',
							'<span class="eltdf-icon-shortcode eltdf-normal   "><i class="eltdf-icon-linea-icon icon-arrows-slim-right eltdf-icon-element" style=""></i></span>'
						],
						onInitialize: function () {
							slider.css('visibility', 'visible');
						},
						onInitialized: function () {
							$('.eltdf-testimonials-image-pagination .owl-item').filter('.active').eq(1).find('img').css("transform", "scale(1)");
							$('.eltdf-testimonials-image-pagination .owl-item').find('.eltdf-testimonial-author').css("opacity", "0");
							$('.eltdf-testimonials-image-pagination .owl-item').filter('.active').eq(1).find('.eltdf-testimonial-author').css("opacity", "1");
						},
						onDrag: function (e) {
							if (eltdf.body.hasClass('eltdf-smooth-page-transitions-fadeout')) {
								var sliderIsMoving = e.isTrigger > 0;
								
								if (sliderIsMoving) {
									slider.addClass('eltdf-slider-is-moving');
								}
							}
						},
						onDragged: function () {
							if (eltdf.body.hasClass('eltdf-smooth-page-transitions-fadeout') && slider.hasClass('eltdf-slider-is-moving')) {
								
								setTimeout(function () {
									slider.removeClass('eltdf-slider-is-moving');
								}, 500);
							}
						},
						onTranslated: function(property) {
							var activeItem = slider.find('.owl-item.active').eq(1).find('.eltdf-tsp-item').data('index');
							
							contentItems.removeClass('active');
							contentItems.eq(activeItem).addClass('active');
							
							$('.eltdf-testimonials-image-pagination .owl-item').filter('.active').eq(1).find('img').css("transform", "scale(1)");
							$('.eltdf-testimonials-image-pagination .owl-item').filter('.active').eq(1).find('.eltdf-testimonial-author').css("opacity", "1");
						},
						onTranslate: function() {
							$('.eltdf-testimonials-image-pagination .owl-item').find('img').css("transform", "scale(0.7)");
							$('.eltdf-testimonials-image-pagination .owl-item').find('.eltdf-testimonial-author').css("opacity", "0");
						},
					});
					
				});
			});
		}
	}
	
})(jQuery);