<div class="eltdf-testimonials-holder clearfix <?php echo esc_attr($holder_classes); ?>">
	<div class="eltdf-testimonials eltdf-testimonials-image-pagination-inner">
		<?php if ( $query_results->have_posts() ):
			$pagination_images = array();
			$author_array = array();
			$position_array = array();
			while ( $query_results->have_posts() ) : $query_results->the_post();
				$current_id = get_the_ID();
				$title    	= get_post_meta( get_the_ID(), 'eltdf_testimonial_title', true );
				$text   	= get_post_meta( get_the_ID(), 'eltdf_testimonial_text', true );
				$author   	= get_post_meta( get_the_ID(), 'eltdf_testimonial_author', true );
				$author_array[]   	= get_post_meta( get_the_ID(), 'eltdf_testimonial_author', true );
				$position 	= get_post_meta( get_the_ID(), 'eltdf_testimonial_author_position', true );
				$position_array[] 	= get_post_meta( get_the_ID(), 'eltdf_testimonial_author_position', true );
				$pagination_images[]  = get_the_post_thumbnail(get_the_ID(), array(144, 144));
				?>
				
				<div class="eltdf-testimonial-content" id="eltdf-testimonials-<?php echo esc_attr( $current_id ) ?>">
					<div class="eltdf-testimonial-text-holder">
						<span class="eltdf-testimonial-mark">”</span>
						<?php if ( ! empty( $text ) ) { ?>
							<h4 class="eltdf-testimonial-text"><?php echo esc_html( $text ); ?></h4>
						<?php } ?>
						
						<?php if ( ! empty( $author ) ) { ?>
							<p class="eltdf-testimonials-author-name"><?php echo esc_html( $author ); ?></p>
						<?php } ?>
						<?php if ( ! empty( $position ) ) { ?>
							<p class="eltdf-testimonials-author-job"><?php echo esc_html( $position ); ?></p>
						<?php } ?>
					</div>
				</div>
			
			<?php
			endwhile;
		else:
			echo esc_html__( 'Sorry, no posts matched your criteria.', 'justicia-core' );
		endif;
		
		wp_reset_postdata();
		?>
	</div>
	<ul id="eltdf-testimonial-pagination" class="clearfix" <?php echo etienne_elated_get_inline_attrs( $data_attr ) ?>>
		<?php foreach ($pagination_images as $key => $image) : ?>
			<li class="eltdf-tsp-item" data-index="<?php echo esc_attr($key);?>">
				<?php print $image; ?>
			</li>
		<?php endforeach; ?>
	</ul>
</div>