<?php
$share_type = isset( $share_type ) ? $share_type : 'dropdown';
?>
<?php if ( etienne_elated_core_plugin_installed() && etienne_elated_options()->getOptionValue( 'enable_social_share' ) === 'yes' && etienne_elated_options()->getOptionValue( 'enable_social_share_on_portfolio_item' ) === 'yes' ) { ?>
	<div class="eltdf-pli-share">
		<?php echo etienne_elated_get_social_share_html( array( 'type' => $share_type, 'dropdown_behavior' => 'left'  ) ); ?>
	</div>
<?php } ?>