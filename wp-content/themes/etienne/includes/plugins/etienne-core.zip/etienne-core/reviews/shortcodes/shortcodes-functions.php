<?php

if ( ! function_exists( 'etienne_core_include_reviews_shortcodes_files' ) ) {
	/**
	 * Loades all shortcodes by going through all folders that are placed directly in shortcodes folder
	 */
	function etienne_core_include_reviews_shortcodes_files() {
		foreach ( glob( ETIENNE_CORE_ABS_PATH . '/reviews/shortcodes/*/load.php' ) as $shortcode_load ) {
			include_once $shortcode_load;
		}
	}
	
	add_action( 'etienne_core_action_include_shortcodes_file', 'etienne_core_include_reviews_shortcodes_files' );
}