<?php

if ( ! function_exists( 'etienne_core_import_object' ) ) {
	function etienne_core_import_object() {
		$etienne_core_import_object = new EtienneCoreImport();
	}
	
	add_action( 'init', 'etienne_core_import_object' );
}

if ( ! function_exists( 'etienne_core_data_import' ) ) {
	function etienne_core_data_import() {
		$importObject = EtienneCoreImport::getInstance();
		
		if ( $_POST['import_attachments'] == 1 ) {
			$importObject->attachments = true;
		} else {
			$importObject->attachments = false;
		}
		
		$folder = "etienne/";
		if ( ! empty( $_POST['example'] ) ) {
			$folder = $_POST['example'] . "/";
		}
		
		$importObject->import_content( $folder . $_POST['xml'] );
		
		die();
	}
	
	add_action( 'wp_ajax_etienne_core_data_import', 'etienne_core_data_import' );
}

if ( ! function_exists( 'etienne_core_widgets_import' ) ) {
	function etienne_core_widgets_import() {
		$importObject = EtienneCoreImport::getInstance();
		
		$folder = "etienne/";
		if ( ! empty( $_POST['example'] ) ) {
			$folder = $_POST['example'] . "/";
		}
		
		$importObject->import_widgets( $folder . 'widgets.txt', $folder . 'custom_sidebars.txt' );
		
		die();
	}
	
	add_action( 'wp_ajax_etienne_core_widgets_import', 'etienne_core_widgets_import' );
}

if ( ! function_exists( 'etienne_core_options_import' ) ) {
	function etienne_core_options_import() {
		$importObject = EtienneCoreImport::getInstance();
		
		$folder = "etienne/";
		if ( ! empty( $_POST['example'] ) ) {
			$folder = $_POST['example'] . "/";
		}
		
		$importObject->import_options( $folder . 'options.txt' );
		
		die();
	}
	
	add_action( 'wp_ajax_etienne_core_options_import', 'etienne_core_options_import' );
}

if ( ! function_exists( 'etienne_core_other_import' ) ) {
	function etienne_core_other_import() {
		$importObject = EtienneCoreImport::getInstance();
		
		$folder = "etienne/";
		if ( ! empty( $_POST['example'] ) ) {
			$folder = $_POST['example'] . "/";
		}
		
		$importObject->import_options( $folder . 'options.txt' );
		$importObject->import_widgets( $folder . 'widgets.txt', $folder . 'custom_sidebars.txt' );
		$importObject->import_menus( $folder . 'menus.txt' );
		$importObject->import_settings_pages( $folder . 'settingpages.txt' );

		$importObject->eltdf_update_meta_fields_after_import($folder);
		$importObject->eltdf_update_options_after_import($folder);

		if ( etienne_core_is_revolution_slider_installed() ) {
			$importObject->rev_slider_import( $folder );
		}
		
		die();
	}
	
	add_action( 'wp_ajax_etienne_core_other_import', 'etienne_core_other_import' );
}