<?php
namespace EtienneCore\CPT\Shortcodes\ShowcaseLayout;

use EtienneCore\Lib;

class ShowcaseLayout implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'eltdf_showcase_layout';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Showcase Layout', 'etienne-core' ),
					'base'                      => $this->getBase(),
					'category'                  => esc_html__( 'by ETIENNE', 'etienne-core' ),
					'icon'                      => 'icon-wpb-showcase-layout extended-custom-icon',
					'allowed_container_element' => 'vc_row',
					'params'                    => array(
						array(
							'type'			=> 'attach_image',
							'param_name'	=> 'main_image',
							'heading'		=> esc_html__( 'Main Image', 'etienne-core' ),
							'description'	=> esc_html__( 'Select image from media library', 'etienne-core' ),
						),
						array(
							'type'			=> 'attach_image',
							'param_name'	=> 'additional_image',
							'heading'		=> esc_html__( 'Additional Image', 'etienne-core' ),
							'description'	=> esc_html__( 'Select image from media library', 'etienne-core' ),
						),
						array(
							'type'			=> 'textfield',
							'param_name'	=> 'title',
							'heading'		=> esc_html__( 'Title', 'etienne-core' ),
							'admin_label' 	=> true,
						),
						array(
							'type'			=> 'textfield',
							'param_name'	=> 'subtitle',
							'heading'		=> esc_html__( 'Subtitle', 'etienne-core' ),
						),
						array(
							'type'			=> 'textfield',
							'param_name'	=> 'text',
							'heading'		=> esc_html__( 'Text', 'etienne-core' ),
						),
						array(
							'type'        	=> 'textfield',
							'param_name'  	=> 'button_text',
							'heading'     	=> esc_html__( 'Button Text', 'etienne-core' ),
						),
						array(
							'type'      	=> 'textfield',
							'param_name' 	=> 'button_link',
							'heading'    	=> esc_html__( 'Button Link', 'etienne-core' ),
							'dependency' 	=> array( 'element' => 'button_text', 'not_empty' => true ),
						),
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$args   = array(
			'main_image' 		=> '',
			'additional_image' 	=> '',
			'title' 			=> '',
			'subtitle' 			=> '',
			'text' 				=> '',
			'button_text' 		=> '',
			'button_link' 		=> '',
		);
		
		$params = shortcode_atts( $args, $atts );

		$params['button_params']	= $this->getButtonParameters( $params );

		$html = etienne_core_get_shortcode_module_template_part( 'templates/showcase-layout-template', 'showcase-layout', '', $params );
		
		return $html;
	}


	private function getButtonParameters( $params ) {
		$button_params_array = array();
		
		if ( ! empty( $params['button_text'] ) ) {
			$button_params_array['text'] = $params['button_text'];
		}

		if ( ! empty( $params['button_link'] ) ) {
			$button_params_array['link'] = $params['button_link'];
		}
		
		$button_params_array['type'] = 'solid';
		$button_params_array['size'] = 'medium';
		$button_params_array['target'] = '_self';
		$button_params_array['custom_class'] = 'eltdf-iis-btn';
		
		return $button_params_array;
	}
}