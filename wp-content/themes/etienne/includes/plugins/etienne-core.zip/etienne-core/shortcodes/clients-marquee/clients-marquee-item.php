<?php
namespace EtienneCore\CPT\Shortcodes\ClientsMarqueeItem;

use EtienneCore\Lib;

class ClientsMarqueeItem implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'eltdf_clients_marquee_item';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'                    => esc_html__( 'Clients Item', 'etienne-core' ),
					'base'                    => $this->getBase(),
					'category'                => esc_html__( 'by ETIENNE', 'etienne-core' ),
					'icon'                    => 'icon-wpb-clients-marquee-item extended-custom-icon',
					'as_child'                => array( 'only' => 'eltdf_clients_marquee' ),
					'as_parent'               => array( 'except' => 'vc_row' ),
					'show_settings_on_create' => true,
					'params'                  => array(
						array(
							'type'        => 'attach_image',
							'param_name'  => 'image',
							'heading'     => esc_html__( 'Image', 'etienne-core' ),
							'description' => esc_html__( 'Select image from media library', 'etienne-core' )
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'link',
							'heading'    => esc_html__( 'Custom Link', 'etienne-core' )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'target',
							'heading'     => esc_html__( 'Custom Link Target', 'etienne-core' ),
							'value'       => array_flip( etienne_elated_get_link_target_array() ),
							'save_always' => true
						)
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$args   = array(
			'image'       => '',
			'image_size'  => 'full',
			'link'        => '',
			'target'      => '_self'
		);
		$params = shortcode_atts( $args, $atts );
		
		$params['holder_classes'] = $this->getHolderClasses( $params, $args );
		$params['image']          = $this->getMarqueeImage( $params );
		$params['target']         = ! empty( $params['target'] ) ? $params['target'] : $args['target'];
		
		$html = etienne_core_get_shortcode_module_template_part( 'templates/clients-marquee-item', 'clients-marquee', '', $params );
		
		return $html;
	}
	
	private function getHolderClasses( $params, $args ) {
		$holderClasses = array();
		
		$holderClasses[] = ! empty( $params['link'] ) ? 'eltdf-cmi-has-link' : 'eltdf-cmi-no-link';
		
		return implode( ' ', $holderClasses );
	}
	
	private function getMarqueeImage( $params ) {
		$image_meta = array();
		
		if ( ! empty( $params['image'] ) ) {
			$image_id = $params['image'];
			$image_original = wp_get_attachment_image_src( $image_id, 'full' );
			$image['url'] = $image_original[0];
			$image['alt'] = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
			
			$image_meta = $image;
		}
		
		return $image_meta;
	}
}