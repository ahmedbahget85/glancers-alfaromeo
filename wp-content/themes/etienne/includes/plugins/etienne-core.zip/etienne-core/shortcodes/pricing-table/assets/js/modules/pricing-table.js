(function($) {
    'use strict';

    var pricingTable = {};
    eltdf.modules.pricingTable = pricingTable;

    pricingTable.eltdfOnDocumentReady = eltdfOnDocumentReady;
    pricingTable.eltdfOnWindowLoad = eltdfOnWindowLoad;

    $(document).ready(eltdfOnDocumentReady);
    $(window).load(eltdfOnWindowLoad);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function eltdfOnDocumentReady() {
        eltdfPricingTableAnimation();
    }

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function eltdfOnWindowLoad() {

    }

    /*
 **	Init PricingTable shortcode animation
 */
    function eltdfPricingTableAnimation() {
        var pricingTableSC = $('.eltdf-pricing-tables.eltdf-pt-has-animation');

        if (pricingTableSC.length && !Modernizr.touch) {
            var showItem = function(item) {
                item
                    .addClass('eltdf-item-show')
                    .one(eltdf.transitionEnd, function() {
                        item.addClass('eltdf-item-shown');
                    });
            }

            var show = function (list) {
                var items = list.find('.eltdf-price-table'),
                    cycle = 2, // rewind delay
                    counter = 0,
                    delay = 300;

                var resetCounter = function() {
                    counter = 0;
                }

                items.appear(function(l) {
                    var item = $(this);

                    counter++;
                    counter == cycle && resetCounter();

                    item.css('transition-delay', counter * delay+ 'ms');
                    showItem(item);
                }, {accX: 0, accY: eltdfGlobalVars.vars.eltdfElementAppearAmount});
            }

            pricingTableSC.appear(function () {
                show($(this));
            }, {
                accX: 0,
                accY: eltdfGlobalVars.vars.eltdfElementAppearAmount
            });
        }
    }

})(jQuery);