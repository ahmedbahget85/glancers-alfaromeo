<div class="eltdf-image-info-slide-holder">
	<img class="eltdf-bg-image-mobile" src="<?php echo wp_get_attachment_url($background_image); ?>" alt="<?php echo get_the_title($background_image) ?>" />
	<div class="eltdf-bg-image-desktop" style="background-image: url(<?php echo wp_get_attachment_url($background_image); ?>)"></div>
	<div class="eltdf-content-holder">
		<div class="eltdf-content-inner">
			<?php if (!empty($subtitle)) : ?>
				<h6 class="eltdf-iis-subtitle">
					<?php echo esc_attr($subtitle); ?>
				</h6>
			<?php endif; ?>
			<?php if (!empty($title)) : ?>
				<h3 class="eltdf-iis-title">
					<?php echo esc_attr($title); ?>
				</h3>
			<?php endif; ?>
			<?php if (!empty($text)) : ?>
				<p class="eltdf-iis-text">
					<?php echo esc_attr($text); ?>
				</p>
			<?php endif; ?>
			<?php if (!empty($button_text)) : ?>
				<?php echo etienne_elated_get_button_html($button_params); ?>
			<?php endif; ?>
		</div>
	</div>
	<div class="eltdf-bg-holder"></div>
</div>
