<?php

include_once ETIENNE_CORE_SHORTCODES_PATH . '/image-marquee/functions.php';
include_once ETIENNE_CORE_SHORTCODES_PATH . '/image-marquee/image-marquee.php';