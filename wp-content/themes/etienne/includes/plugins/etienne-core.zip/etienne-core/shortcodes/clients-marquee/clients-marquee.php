<?php
namespace EtienneCore\CPT\Shortcodes\ClientsMarquee;

use EtienneCore\Lib;

class ClientsMarquee implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'eltdf_clients_marquee';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'            => esc_html__( 'Clients Marquee', 'etienne-core' ),
					'base'            => $this->getBase(),
					'category'        => esc_html__( 'by ETIENNE', 'etienne-core' ),
					'icon'            => 'icon-wpb-clients-marquee extended-custom-icon',
					'as_parent'       => array( 'only' => 'eltdf_clients_marquee_item' ),
					'content_element' => true,
					'js_view'         => 'VcColumnView',
					'show_settings_on_create' => false,
					'params'          => array(
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$args = array(
			'number_of_visible_items' => '4',
			'items_hover_animation'   => 'switch-images'
		);
		
		$params = shortcode_atts( $args, $atts );
		$params['content'] = $content;
		$html = etienne_core_get_shortcode_module_template_part( 'templates/clients-marquee', 'clients-marquee', '', $params );
		
		return $html;
	}

}