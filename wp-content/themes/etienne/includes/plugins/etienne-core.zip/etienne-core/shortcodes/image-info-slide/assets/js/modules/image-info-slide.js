(function ($) {
	'use strict';

	var imageInfoSlide = {};
	eltdf.modules.imageInfoSlide = imageInfoSlide;

	imageInfoSlide.eltdfImageInfoSlide = eltdfImageInfoSlide;
	imageInfoSlide.eltdfOnDocumentReady = eltdfOnDocumentReady;

	$(document).ready(eltdfOnDocumentReady);

	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function eltdfOnDocumentReady() {
		eltdfImageInfoSlide();
	}

	/**
	 * Init Image Info Slide Shortcode
	 */
	function eltdfImageInfoSlide() {
		var slides = $('.eltdf-image-info-slide-holder');

		slides.length &&
		!Modernizr.touch &&
			slides.appear(function () {
				$(this).addClass('eltdf-appeared');
			}, {
				accX: 0,
				accY: eltdfGlobalVars.vars.eltdfElementAppearAmount
			});
	}
})(jQuery);