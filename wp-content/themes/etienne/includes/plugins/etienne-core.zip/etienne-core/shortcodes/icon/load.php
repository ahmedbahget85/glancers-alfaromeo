<?php

include_once ETIENNE_CORE_SHORTCODES_PATH . '/icon/functions.php';
include_once ETIENNE_CORE_SHORTCODES_PATH . '/icon/icon.php';