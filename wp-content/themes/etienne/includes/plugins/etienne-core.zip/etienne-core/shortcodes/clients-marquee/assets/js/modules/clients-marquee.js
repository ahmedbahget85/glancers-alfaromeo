(function ($) {
    'use strict';

    var clientsMarquee = {};
    eltdf.modules.clientsMarquee = clientsMarquee;

    clientsMarquee.eltdfClientsMarquee = eltdfClientsMarquee;
    clientsMarquee.eltdfOnDocumentReady = eltdfOnDocumentReady;

    $(document).ready(eltdfOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function eltdfOnDocumentReady() {
        eltdfClientsMarquee().init();
    }

    /**
     * Init Clients Marquee Shortcode
     */
    function eltdfClientsMarquee() {
        var setup = function (marquee) {
            var marqueeElements = marquee.find('.eltdf-cm-inner'),
                originalItem = marqueeElements.filter('.eltdf-original'),
                auxItem = marqueeElements.filter('.eltdf-aux'),
                delta = 1;

            marquee.data('hovering', false)
            marqueeEffect(marquee, originalItem, delta);
            marqueeEffect(marquee, auxItem, delta);
            hoverListener(marquee);
        }

        var hoverListener = function (marquee) {
            marquee
                .on('mouseenter', function () {
                    marquee.data('hovering', true)
                })
                .on('mouseleave', function () {
                    marquee.data('hovering', false)
                });
        }

        var marqueeEffect = function (marquee, item, delta) {
            var currentPos = 0,
                w = eltdf.windowWidth;

            var loop = function () {
                currentPos = !marquee.data('hovering') ? currentPos - delta : currentPos;

                if (item.position().left <= -item.width() || w != eltdf.windowWidth) {
                    reset();
                } else {
                    item.css('transform', 'translate3d(' + currentPos + 'px,0,0');
                }

                requestAnimationFrame(loop);
            }

            //normal reset vs resize reset
            var reset = function () {
                if (w == eltdf.windowWidth) {
                    item.css('left', item.hasClass('eltdf-original') ? item.width() : 0);
                } else {
                    item.css('left', 0);
                }

                item.css('transform', 'translate3d(0,0,0)');

                currentPos = 0;
                w = eltdf.windowWidth;
            }

            item.waitForImages(loop)
        }

        return {
            init: function () {
                var marquees = $('.eltdf-clients-marquee-holder');

                if (marquees.length) {
                    marquees.each(function () {
                        var marquee = $(this);

                        setup(marquee);
                    });
                }
            }
        }
    }
})(jQuery);