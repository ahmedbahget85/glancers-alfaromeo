<div class="eltdf-clients-marquee-holder">
	<div class="eltdf-cm-inner eltdf-original">
		<?php echo do_shortcode($content); ?>
	</div>
	<div class="eltdf-cm-inner eltdf-aux">
		<?php echo do_shortcode($content); ?>
	</div>
</div>