(function ($) {
	'use strict';

	var progressBar = {};
	eltdf.modules.progressBar = progressBar;

	progressBar.eltdfInitProgressBars = eltdfInitProgressBars;


	progressBar.eltdfOnDocumentReady = eltdfOnDocumentReady;

	$(document).ready(eltdfOnDocumentReady);

	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function eltdfOnDocumentReady() {
		eltdfInitProgressBars();
	}

	/*
	 **	Horizontal progress bars shortcode
	 */
	function eltdfInitProgressBars() {
		var progressBars = $('.eltdf-progress-bar');

		if (progressBars.length) {
			progressBars.appear(function () {
				var progressBar = $(this),
					barContent = progressBar.find('.eltdf-pb-content'),
					percentage = barContent.data('percentage'),
					delay = Math.floor(Math.random() * 5);

				barContent.css({
					'width': percentage + '%',
					'transition-delay': delay * 100 + 'ms'
				});

				eltdfInitToCounterProgressBar(progressBar, percentage, delay);
			});
		}
	}

	/*
	 **	Counter for horizontal progress bars percent from zero to defined percent
	 */
	function eltdfInitToCounterProgressBar(progressBar, percentage, delay) {
		var percentage = parseFloat(percentage),
			percent = progressBar.find('.eltdf-pb-percent');


		if (percent.length) {
			percent.css({
				'left': percentage + '%',
				'opacity': '1',
				'transition-delay': delay * 100 + 'ms'
			});

			percent.countTo({
				from: 0,
				to: percentage,
				speed: 1000,
				refreshInterval: 50
			});
		}
	}

})(jQuery);