<div class="eltdf-vss-ms-section" <?php echo etienne_elated_get_inline_attrs($content_data); ?> <?php etienne_elated_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>