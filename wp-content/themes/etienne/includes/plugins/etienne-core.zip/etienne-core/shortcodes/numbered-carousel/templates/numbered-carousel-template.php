<div class="eltdf-numbered-carousel <?php echo esc_attr($holder_classes); ?> ">
    <?php if (!empty($items)) : ?>
        <?php $l = 1; ?>
        <div class="eltdf-nc-bg-items">
            <?php foreach ($items as $item) : ?>
                <?php if ($item['media_type'] == 'image') : ?>
                    <div class="eltdf-nc-bg-item eltdf-nc-image" 
                        data-index=<?php echo esc_attr($l); ?> 
                        style="background-image:url('<?php echo wp_get_attachment_url($item['image']); ?>');">
                    </div>
                <?php else : ?>
                    <div class="eltdf-nc-bg-item eltdf-nc-video"  data-index=<?php echo esc_attr($l); ?> >
                        <video autoplay loop muted>
                            <source src="<?php echo esc_url($item['video_url']); ?>" type="video/mp4">
                        </video>
                    </div>
                <?php endif; ?>
                <?php $l++; ?>
            <?php endforeach; ?>
        </div>
        <div class="eltdf-nc-grid">
            <?php for ($j = 1; $j <= 5; $j++) : ?>
                <span class="eltdf-nc-grid-line"></span>
            <?php endfor; ?>
        </div>
        <div class="eltdf-nc-content">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <?php $i = 1; ?>
                    <?php foreach ($items as $item) : 
                        $content = array (
                                array("subtitle", 'h6', $item['subtitle']),
                                array("title", 'h1', $item['title']),
                                array("text", 'p', $item['text']),
                            );
                        ?>
                        <div class="eltdf-nc-item swiper-slide" data-index=<?php echo esc_attr($i); ?>>
                            <div class="eltdf-nc-item-inner">
                                <?php $k = 0; ?>
                                <?php foreach ($content as $contentItem) : ?>
                                    <div class="eltdf-nc-item-<?php echo esc_attr($content[$k][0]); ?>-wrapper">
                                        <<?php echo esc_attr($content[$k][1]); ?> class="eltdf-nc-item-<?php echo esc_attr($content[$k][0]); ?>">
                                            <?php echo esc_attr($content[$k][2]); ?>
                                        </<?php echo esc_attr($content[$k][1]); ?>>
                                    </div>
                                    <?php $k++; ?>
                                <?php endforeach; ?>
                                <?php if(!empty($item['link']) && !empty($item['link_text'])) : ?>
                                    <div class="eltdf-nc-item-btn-wrapper">
                                        <?php echo etienne_elated_get_button_html(array(
                                            'link' => $item['link'],
                                            'text' => $item['link_text'],
                                            'type' => 'solid',
                                            'size' => 'medium',
                                            'custom_class' => 'eltdf-nc-item-btn'
                                        )); ?>
                                    </div>
                                <?php endif; ?>
                            </div>  
                            <div class="eltdf-nc-item-number-wrapper">
                                <span class="eltdf-nc-item-number">
                                <?php echo esc_attr($i); ?>
                                </span>
                            </div>
                        </div>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <div class="eltdf-nc-indicators">
            <?php $n = 1; ?>
            <?php foreach ($items as $item) : ?>
                <span class="eltdf-nc-indicator" data-index=<?php echo esc_attr($n); ?>></span>
                <?php $n++; ?>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>