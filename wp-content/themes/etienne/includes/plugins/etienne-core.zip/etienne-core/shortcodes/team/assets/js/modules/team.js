(function ($) {
    'use strict';

    var team = {};

    eltdf.modules.team = team;
    team.eltdfTeamAnimation = eltdfTeamAnimation;
    team.eltdfOnDocumentReady = eltdfOnDocumentReady;

    $(document).ready(eltdfOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function eltdfOnDocumentReady() {
        eltdfTeamAnimation();
    }

    /*
     **	Init team shortcode animation
     */
    function eltdfTeamAnimation() {
        var teamSC = $('.eltdf-team-has-animation');

        if (teamSC.length && !Modernizr.touch) {
            var show = function (team) {
                team
                    .addClass('eltdf-item-show')
                    .one(eltdf.transitionEnd, function () {
                        team.addClass('eltdf-item-shown');
                    });
            }

            teamSC.each(function () {
                var team = $(this),
                    delay = parseInt(team.data('delay')) || 0;

                team.css('transition-delay', delay + 'ms');
                team.find('.eltdf-team-image').css('transition-delay', delay + 'ms');
                team.find('.eltdf-team-info').css('transition-delay', (delay + 300) + 'ms');
            })

            teamSC.appear(function () {
                show($(this));
            }, {
                accX: 0,
                accY: eltdfGlobalVars.vars.eltdfElementAppearAmount
            });
        }
    }

})(jQuery);