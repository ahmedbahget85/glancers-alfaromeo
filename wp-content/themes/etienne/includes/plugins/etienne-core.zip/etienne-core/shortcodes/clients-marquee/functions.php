<?php

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Eltdf_Clients_Marquee extends WPBakeryShortCodesContainer {}
}

if ( ! function_exists( 'etienne_core_add_clients_marquee_shortcodes' ) ) {
	function etienne_core_add_clients_marquee_shortcodes( $shortcodes_class_name ) {
		$shortcodes = array(
			'EtienneCore\CPT\Shortcodes\ClientsMarquee\ClientsMarquee',
			'EtienneCore\CPT\Shortcodes\ClientsMarqueeItem\ClientsMarqueeItem'
		);
		
		$shortcodes_class_name = array_merge( $shortcodes_class_name, $shortcodes );
		
		return $shortcodes_class_name;
	}
	
	add_filter( 'etienne_core_filter_add_vc_shortcode', 'etienne_core_add_clients_marquee_shortcodes' );
}

if ( ! function_exists( 'etienne_core_set_clients_marquee_icon_class_name_for_vc_shortcodes' ) ) {
	/**
	 * Function that set custom icon class name for clients marquee shortcode to set our icon for Visual Composer shortcodes panel
	 */
	function etienne_core_set_clients_marquee_icon_class_name_for_vc_shortcodes( $shortcodes_icon_class_array ) {
		$shortcodes_icon_class_array[] = '.icon-wpb-clients-marquee';
		$shortcodes_icon_class_array[] = '.icon-wpb-clients-marquee-item';
		
		return $shortcodes_icon_class_array;
	}
	
	add_filter( 'etienne_core_filter_add_vc_shortcodes_custom_icon_class', 'etienne_core_set_clients_marquee_icon_class_name_for_vc_shortcodes' );
}