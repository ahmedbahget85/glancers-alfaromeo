<div class="eltdf-showcase-layout-holder">
	<div class="eltdf-main-image-holder">
		<img class="eltdf-main-image" src="<?php echo wp_get_attachment_url($main_image); ?>" alt="<?php echo get_the_title($main_image) ?>" />
	</div>
	<div class="eltdf-additional-image-holder">
		<img class="eltdf-additional-image" src="<?php echo wp_get_attachment_url($additional_image); ?>" alt="<?php echo get_the_title($additional_image) ?>" />
	</div>
	<div class="eltdf-content-holder">
		<div class="eltdf-content-inner">
			<?php if (!empty($subtitle)) : ?>
				<h6 class="eltdf-sl-subtitle">
					<?php echo esc_attr($subtitle); ?>
				</h6>
			<?php endif; ?>
			<?php if (!empty($title)) : ?>
				<h3 class="eltdf-sl-title">
					<?php echo esc_attr($title); ?>
				</h3>
			<?php endif; ?>
			<?php if (!empty($text)) : ?>
				<p class="eltdf-sl-text">
					<?php echo esc_attr($text); ?>
				</p>
			<?php endif; ?>
			<?php if (!empty($button_text)) : ?>
				<?php echo etienne_elated_get_button_html($button_params); ?>
			<?php endif; ?>
		</div>
	</div>
</div>
