<?php
namespace EtienneCore\CPT\Shortcodes\NumberedCarousel;

use EtienneCore\Lib;

class NumberedCarousel implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'eltdf_numbered_carousel';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	/**
	 * Maps shortcode to Visual Composer. Hooked on vc_before_init
	 */
	public function vcMap() {
		if(function_exists('vc_map')) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Numbered Carousel', 'etienne-core' ),
					'base'                      => $this->getBase(),
					'category'                  => esc_html__( 'by ETIENNE', 'etienne-core' ),
					'icon'                      => 'icon-wpb-numbered-carousel extended-custom-icon',
                    'allowed_container_element' => 'vc_row',
					'params'                    => array(
                        array(
                            'type' => 'param_group',
                            'heading' => esc_html__( 'Items', 'etienne-core' ),
                            'param_name' => 'items',
                            'params' => array(
                                array(
                                    'type'       => 'dropdown',
                                    'param_name' => 'media_type',
                                    'heading'    => esc_html__( 'Media Type', 'etienne-core' ),
                                    'value'      => array(
                                        esc_html__( 'Image', 'etienne-core' ) => 'image',
                                        esc_html__( 'Video', 'etienne-core' ) => 'video'
                                    ),
                                    'admin_label' => true,
                                    'save_always' => true,
                                ),
                            	array(
                            	    'type'        => 'attach_image',
                                    'param_name'  => 'image',
                            	    'heading'     => esc_html__( 'Image', 'etienne-core' ),
                                    'dependency' 	=> array( 'element' => 'media_type', 'value' => 'image' )
                                ),
                                array(
                                    'type'       => 'textfield',
                                    'param_name' => 'video_url',
                                    'heading'    => esc_html__('Video Url', 'tonda-core'),
                                    'dependency' 	=> array( 'element' => 'media_type', 'value' => 'video' )
                                ),
                                array(
                                    'type'        => 'textfield',
                                    'param_name'  => 'title',
                                    'heading'     => esc_html__( 'Title', 'etienne-core' ),
                                    'admin_label' => true,
                                ),
                                array(
                                    'type'        => 'textfield',
                                    'param_name'  => 'subtitle',
                                    'heading'     => esc_html__( 'Subtitle', 'etienne-core' ),
                                ),
                                array(
                                    'type'        => 'textfield',
                                    'param_name'  => 'text',
                                    'heading'     => esc_html__( 'Text', 'etienne-core' ),
                                ),
                                array(
                                    'type'        => 'textfield',
                                    'param_name'  => 'link',
                                    'heading'     => esc_html__( 'Link', 'etienne-core' ),
                                    'admin_label' => true,
                                ),
                                array(
                                    'type'       => 'textfield',
                                    'param_name' => 'link_text',
                                    'heading'    => esc_html__( 'Link Text', 'etienne-core' ),
                                    'dependency' => array( 'element' => 'link', 'not_empty' => true )
                                ),
                                array(
                                    'type'       => 'dropdown',
                                    'param_name' => 'target',
                                    'heading'    => esc_html__( 'Link target', 'etienne-core' ),
                                    'value'      => array_flip( etienne_elated_get_link_target_array() ),
                                    'dependency' => array( 'element' => 'link', 'not_empty' => true )
                                ),
                            )
                        ),
                        array(
							'type'       => 'dropdown',
							'param_name' => 'change_slides_on_scroll',
							'heading'    => esc_html__( 'Change Slides On Scroll', 'etienne-core' ),
							'value'      => array_flip( etienne_elated_get_yes_no_select_array( false, true ) ),
						),
                    )
				)
			);
		}
	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @param $content string shortcode content
	 * @return string
	 */
	public function render($atts, $content = null) {
		$args = array(
            'items'              => '',
            'change_slides_on_scroll'  => 'yes',
		);
		
		$params = shortcode_atts($args, $atts);
        $params['content'] = $content;
        $params['items'] = json_decode(urldecode($params['items']), true);
		$params['holder_classes'] = $this->getHolderClasses( $params );

		$html = etienne_core_get_shortcode_module_template_part('templates/numbered-carousel-template', 'numbered-carousel', '', $params);
		
		return $html;
    }

    private function getHolderClasses( $params ) {
		$holderClasses = array();
		
		$holderClasses[] = $params['change_slides_on_scroll'] === 'yes' ? 'eltdf-change-on-scroll' : '';
		
		return implode( ' ', $holderClasses );
	}
}