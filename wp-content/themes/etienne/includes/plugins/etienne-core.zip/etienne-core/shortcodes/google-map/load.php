<?php

include_once ETIENNE_CORE_SHORTCODES_PATH . '/google-map/functions.php';
include_once ETIENNE_CORE_SHORTCODES_PATH . '/google-map/google-map.php';