<div class="eltdf-clients-grid-holder eltdf-grid-list eltdf-disable-bottom-space <?php echo esc_attr( $holder_classes ); ?>">
	<div class="eltdf-cg-inner eltdf-outer-space">
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>