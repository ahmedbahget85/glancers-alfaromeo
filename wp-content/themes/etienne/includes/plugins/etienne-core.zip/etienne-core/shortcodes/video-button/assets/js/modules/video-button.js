(function ($) {
    'use strict';

    var videoButton = {};

    eltdf.modules.videoButton = videoButton;
    videoButton.eltdfVideoBtnAnimation = eltdfVideoBtnAnimation;
    videoButton.eltdfOnDocumentReady = eltdfOnDocumentReady;

    $(document).ready(eltdfOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function eltdfOnDocumentReady() {
        eltdfVideoBtnAnimation();
    }

    /*
     **	Init video button shortcode animation
     */
    function eltdfVideoBtnAnimation() {
        var videoButton = $('.eltdf-vb-with-icon .eltdf-video-button-play .eltdf-video-btn-play-inner');

        videoButton.length && videoButton.appear(function () {
            var btn = $(this).parent();
            btn.addClass('eltdf-show')
                .one(eltdf.transitionEnd, function () {
                    btn.addClass('eltdf-clickable');
                });
        }, {
            accX: 0,
            accY: eltdfGlobalVars.vars.eltdfElementAppearAmount
        });
    }

})(jQuery);