(function ($) {
    'use strict';

    var imageGallery = {};

    eltdf.modules.imageGallery = imageGallery;
    imageGallery.eltdfImageGalleryAnimation = eltdfImageGalleryAnimation;
    imageGallery.eltdfOnDocumentReady = eltdfOnDocumentReady;

    $(document).ready(eltdfOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function eltdfOnDocumentReady() {
        eltdfImageGalleryAnimation();
    }

    /*
     **	Init ImageGallery shortcode animation
     */
    function eltdfImageGalleryAnimation() {
        var imageGallerySC = $('.eltdf-ig-has-animation');

        if (imageGallerySC.length && !Modernizr.touch) {
            var showItem = function(item) {
				item
					.addClass('eltdf-item-show')
					.one(eltdf.transitionEnd, function() {
						item.addClass('eltdf-item-shown');
					});
			}

            var show = function (gallery) {
				var items = gallery.find('.eltdf-ig-image-inner'),
					cycle = 4, // rewind delay
					counter = 0,
					delay = 300;

				var resetCounter = function() {
					counter = 0;
				}

				items.appear(function(l) {
					var item = $(this);

					counter++;
					counter == cycle && resetCounter();

					item.css('transition-delay', counter * delay+ 'ms');
					showItem(item);
				}, {accX: 0, accY: eltdfGlobalVars.vars.eltdfElementAppearAmount});
            }

            imageGallerySC.appear(function () {
                show($(this));
            }, {
                accX: 0,
                accY: eltdfGlobalVars.vars.eltdfElementAppearAmount
            });
        }
    }

})(jQuery);