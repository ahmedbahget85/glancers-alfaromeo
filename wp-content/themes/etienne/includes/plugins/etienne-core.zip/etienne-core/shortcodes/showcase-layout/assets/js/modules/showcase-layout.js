(function ($) {
	'use strict';

	var showcaseLayout = {};
	eltdf.modules.showcaseLayout = showcaseLayout;

	showcaseLayout.eltdfShowcaseLayout = eltdfShowcaseLayout;
	showcaseLayout.eltdfOnDocumentReady = eltdfOnDocumentReady;

	$(document).ready(eltdfOnDocumentReady);

	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function eltdfOnDocumentReady() {
		eltdfShowcaseLayout();
	}

	/**
	 * Init Showcase Layout Loading FX
	 */
	function eltdfShowcaseLayout() {
		var layout = $('.eltdf-showcase-layout-holder');

		layout.length &&
		!Modernizr.touch &&
			layout.appear(function () {
				$(this).addClass('eltdf-appeared');
			}, {
				accX: 0,
				accY: eltdfGlobalVars.vars.eltdfElementAppearAmount
			});
	}
})(jQuery);