<?php

include_once ETIENNE_INSTAGRAM_SHORTCODES_PATH . '/instagram-list/functions.php';
include_once ETIENNE_INSTAGRAM_SHORTCODES_PATH . '/instagram-list/instagram-list.php';